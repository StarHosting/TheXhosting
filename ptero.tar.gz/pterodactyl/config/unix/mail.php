<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Unix Mail Configuration
    |--------------------------------------------------------------------------
    | Customize the emails you send to your users, with colors, images and
    | text.
    */

    'background-color' => '#1f1d2b',
    'button-color' => '#3869D4',
    'text-color' => '#c3c6ca',
    'header-text-color' => '#FFFF',

];